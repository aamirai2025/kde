# Setting Up GitHub on Kubuntu

## Step-1: Install the Tools

Run the following commands.

```shell
sudo apt update
sudo apt install git ksshaskpass
```

## Step-2: Create SSH Key

Run the following command to create SSH key.


```shell
ssh-keygen -t ed25519 -C "aamir.ai2025@gmail.com"
```

A message to give path to store the key will appear with default path as `~/.ssh`. Press Enter to accept the default path. Passphrase will be asked twice, give the passphrase.

The generated key will be saved to `~/.ssh/id_ed25519.pub`.

The folder tree will look like the one shown below and the file `config` will be added in Step-4.

![image](folder_tree.png){width=500px}

## Step-3: Add Key to GitHub

Run the following command to display the public key created in Step-2.

```shell
cat ~/.ssh/id_ed25519.pub
```

The key will be displayed in the Terminal/Konsole. Select the key using mouse and copy it.

Open GitHub website, go to **Settings** $\rightarrow$ **SSH and GPG keys** $\rightarrow$ **New SSH key**. Give title in title box and paste key in the ssh key box.

## Step-4: Store Key to KDE

Create `~/.config/plasma-workspace/env/askpass.sh` and add configuration in it using the following commands.

```shell
mkdir -p ~/.config/plasma-workspace/env
cat > ~/.config/plasma-workspace/env/askpass.sh << 'EOF'
#!/bin/sh
export SSH_ASKPASS=/usr/bin/ksshaskpass
export SSH_ASKPASS_REQUIRE=prefer
EOF
chmod +x ~/.config/plasma-workspace/env/askpass.sh
```

Create the file `~/.ssh/config` and add the following line.

```
Host github.com
    AddKeysToAgent yes
    IdentityFile ~/.ssh/id_ed25519
```

A dialogue box to enter passphrase will appear, tick **Remember password** and enter the password.

Logout of KDE session and login back again.

## Step-5: Test the Connection

Run the following command.

```shell
ssh -T git@github.com
```

Type **Yes** for the fingerprint prompt and you are done.

## Step-6: Setup Local Folder

### Step-6A: The Repo Folder Doesn't Exist

```shell
mkdir -p ~/aamir/clouds/github
cd ~/aamir/clouds/github
git clone git@github.com:aamirai2025/fall26.git
```

It will clone github repo as local folder.

### Step-6B: The Repo Folder Exists on PC


```shell
cd ~/aamir/clouds/github/fall26
git init -b main
git remote add origin git@github.com:aamirai2025/fall26.git
git pull --rebase origin main
git branch --set-upstream-to=origin/main main
```

## Step-7: Add Your Identity

```shell
git config --global user.name "Aamir Alaud Din"
git config --global user.email "aamir.ai2025@example.com"
```

You are done. Enjoy!
